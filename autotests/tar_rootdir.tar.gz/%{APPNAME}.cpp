#include "%{APPNAME}.h"

%{APPNAMEID}::%{APPNAMEID}()
{}

%{APPNAMEID}::~%{APPNAMEID}()
{}

#include "%{APPNAME}.moc"
